package springmvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import springmvc.service.AddService;

@Controller
public class AddController {
	@RequestMapping("/add")
public ModelAndView add(HttpServletRequest req, HttpServletResponse res) {
		int a=Integer.parseInt(req.getParameter("t1"));
		int b=Integer.parseInt(req.getParameter("t2"));
	
		
		AddService as=new AddService();
		int c= as.add(a, b);
		
		ModelAndView mv=new ModelAndView();
		mv.setViewName("dispaly.jsp");
		mv.addObject("result",c);
		return mv;
	
}
}
